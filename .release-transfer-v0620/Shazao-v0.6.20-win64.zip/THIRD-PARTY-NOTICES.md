# 第三方声明

Shazao 中使用了以下第三方作品。按各自的许可，在此附上它们的版权与许可声明。

| 作品 | 在 Shazao 中的用途 | 许可 |
|---|---|---|
| [Phosphor Icons](https://github.com/phosphor-icons/core) | 图片加载失败时显示的图标（image-broken，regular，v0.5.4 起，路径数据原样嵌入 `src/renderer.cpp`）；状态栏的「代码」图标（code，regular，按原图手绘） | MIT |
| [Tabler Icons](https://github.com/tabler/tabler-icons) | 状态栏的「编辑」「后退」「前进」图标（按原图手绘；「锁定」图标为仿照其风格自绘）；v0.5.8 起侧边栏下方一行与状态栏左端的「文件」（folder）、「最近打开」（history）、「收藏」（star）、「折叠侧边栏」（layout-sidebar-right-collapse）、「展开侧边栏」（layout-sidebar-left-collapse）图标（Tabler Icons 3.46.0，路径数据原样嵌入 `src/app.cpp`，SVG 在 `assets/icons`）；v0.5.11 文件树展开/折叠箭头（chevron-down、chevron-right，Tabler Icons 3.49.0，原样路径及 SVG）；v0.6.6 代码换行状态图标（text-wrap、text-wrap-disabled，同为 3.49.0，原始 SVG 在 `assets/icons`，原生路径等比绘制）；v0.6.6 表格与代码块头尾跳转（transition-top、transition-bottom，3.49.0，原始 SVG 在 `assets/icons`，原始路径等比绘制） | MIT |
| [IconPark](https://github.com/bytedance/IconPark) | 侧边栏「大纲」按钮的图标（mindmap-list，按原图手绘，SVG 在 `assets/icons`） | Apache-2.0 |
| [Codicons](https://github.com/microsoft/vscode-codicons)（VS Code 图标） | v0.6.20 起查找与替换窗口的全部图标（chevron-right、chevron-down、arrow-up、arrow-down、close、case-sensitive、whole-word、regex、list-selection、replace、replace-all）与标签页上的关闭（close），路径数据原样嵌入 `src/ui_theme.cpp`、`src/app.cpp`，原始 SVG 在 `assets/icons/codicons` | CC BY 4.0 |

## Phosphor Icons

```text
MIT License

Copyright (c) 2023 Phosphor Icons

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## Tabler Icons

```text
MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## IconPark

IconPark 由字节跳动（ByteDance）发布，按 Apache License 2.0 许可。

```text
IconPark — https://github.com/bytedance/IconPark
Copyright ByteDance Inc.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
```


## Codicons

Codicons 由 Microsoft 发布，图标按 Creative Commons Attribution 4.0 International（CC BY 4.0）许可。Shazao 使用其路径数据，未作修改，仅按大小缩放与着色。

```text
Codicons — https://github.com/microsoft/vscode-codicons
Copyright (c) Microsoft Corporation.
Icons licensed under the Creative Commons Attribution 4.0 International Public License:
https://creativecommons.org/licenses/by/4.0/legalcode
```


## PELE 1.8.0

[上游项目](https://github.com/obsidianmd/pele)。本地内置图表兼容库，固定版本及文件校验值见 third_party/mermaid-dependencies.json。以下为上游完整许可，含 Lucide 图标的 ISC 声明。

```text
MIT License

Copyright (c) 2026 kepano

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

---

The reset icon of the zoom controls is "rotate-ccw" from Lucide v1.14.0
(https://lucide.dev), under the ISC License:

Copyright (c) 2026 Lucide Icons and Contributors

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

```

## QuickJS-NG 0.17.0

[上游项目](https://github.com/quickjs-ng/quickjs)。静态嵌入 JavaScript 核心，未链接文件、网络或模块标准库。

```text
The MIT License (MIT)

Copyright (c) 2017-2026 Fabrice Bellard
Copyright (c) 2017-2024 Charlie Gordon
Copyright (c) 2023-2026 Ben Noordhuis
Copyright (c) 2023-2026 Saúl Ibarra Corretgé

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

```
