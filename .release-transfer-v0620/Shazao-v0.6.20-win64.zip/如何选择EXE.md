# 选择运行文件

- `Shazao-markdown.exe`：普通版，推荐使用。
- `Shazao-markdown-UPX.exe`：体积较小，启动时先解压，个别安全软件可能误报。

解压后运行其中一个即可。两个文件共用应用设置。
